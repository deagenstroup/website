This program requires:
Python 3.*
wxPython 4.*

info for installing wxPython:
https://wxpython.org/pages/downloads/index.html

After wxPython is installed just run the planner.py file
